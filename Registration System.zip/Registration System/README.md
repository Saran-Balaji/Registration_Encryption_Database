## Abstract
    Registration system is a structure that provides a simple set-up of programs for user enrollment.
## Description
    This project is based on graphical user interface and i use text file approach to save user information.
    This project consist of 2 forms (Signup) and (Login) with strong validations.

## Validation Key Features
* SignUp Form
  * Validation for **all require feilds**
  * Validation for **email format checker**
  * Validation for **strong password**
  * Validation for **duplidate email checker**
* LogIn Form
  * Validation for **all require feilds**
  * Validation for **email format checker**
  * Validation for **existance of email**
  * Validation for **user data**

     
