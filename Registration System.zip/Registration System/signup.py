#---Import Librarires
from Tkinter import *    #in python 2.7, tkinter is Tkinter with capital t -->T
import ttk                # in python 2.7 ttk is not in python, import it separately
try:
    from Tkinter import messagebox
except:
    # Python 2
    import tkMessageBox as messagebox

#----Functions/Actions

def validation():
    if name.get()!="" and email.get()!="" and password.get()!="" and gender.get()!="" and age.get()!="":
        email_check=email_validation()
        password_check=password_validataion()
        duplicate_check=duplicates()
        if email_check:
            if duplicate_check:
                messagebox.showinfo("Information","User email already exists.")
            elif password_check:
                insertion_data()
                messagebox.showinfo("Information","Data Inserted Sucessfully")
                shifting_form()
                wappmsg()
            else:
                messagebox.showerror("Error","Password must contain (min 7 characters, upper and lower case letter, number and symbol)")
        else:
            messagebox.showerror("Error","Email format is invalid.")
    else:
        messagebox.showerror("Error","Fill All The Required Fields")

def shifting_form():
    screen.destroy()
    # import login

def wappmsg():
    import wAppMSG

#ciphering_textfile
def vig(txt='', key=' ', typ='d'):
    if not txt:
        print ("Needs text.Error.")
        return
    if not key:
        print ("Needs key.Error.")
        return
    if typ not in ('d', 'e'):
        print ('Type must be "d" or "e".Error.')
        return

    k_len = len(key)
    k_ints = [ord(i) for i in key]
    txt_ints = [ord(i) for i in txt]
    ret_txt = ''
    for i in range(len(txt_ints)):
        adder = k_ints[i % k_len]
        if typ == 'd':
            adder *= -1

        v = (txt_ints[i] - 32 + adder) % 95

        ret_txt += chr(v + 32)

    return (ret_txt)


def insertion_data():
    with open("insertion.txt",'a') as wr:
        wr.write( vig(name.get(), 'super secret key', 'e')  )  
        wr.write(",")
        wr.write( vig(email.get(), 'super secret key', 'e') )   
        wr.write(",")
        wr.write(vig(password.get(), 'super secret key', 'e'))   
        wr.write(",")
        wr.write(vig(gender.get(), 'super secret key', 'e'))   
        wr.write(",")
        wr.write(vig(age.get(), 'super secret key', 'e'))
        wr.write("\n")   
        
def email_validation():
    temp = email.get() 
    count=-1
    for i in temp:
        count+=1
        if i=="@":
            # if temp[count:len(temp)]=="@gmail.com": #just for gmail
                return True
           # else:
               # return False
    else:
        return False

def password_validataion():
    temp = password.get()
    if len(temp)>=7:
        a,b,c,d=False,False,False,False        
        #use multi varaible for checking pass_validatiom
        for i in temp:
            x = ord(i)
            if x>=65 and x<=90:
                a=True
            elif x>=97 and x<=122:
                b=True
            elif x>=48 and x<=57:
                c=True
            else:
                d=True
        if a and b and c and d:
            return True
        else:
            return False
    else:
        return False
        
def duplicates():
    with open("insertion.txt") as rd:
        data = rd.readline()
        while data!="":
            collection = data.split(",")
            collection[1]= vig(collection[1], 'super secret key', 'd')
            if collection[1]==email.get():
                return True
            data = rd.readline()
        else:
            return False

def shift2pgen():
    screen.destroy()
    import PswdGen

#---Graphical Interface
screen = Tk()
#---variables
name = StringVar()
email = StringVar()
password = StringVar()
gender = StringVar()
age = StringVar()
    #screen-ui
screen.geometry("700x600")
screen.maxsize(width="700",height="600")
screen.minsize(width="700",height="600")
screen.config(bg="light sea green")
screen.title("Registration Details Page")
    #Signuop Title
title = Label(text="SIGN UP",font=("Arial",70,"bold"),padx="5",pady="5",bg="light sea green",fg="DarkGoldenrod1").pack(padx="10",pady="30")
    #signup frame
signup_frame = Frame(screen,width="500",height="400",bg="DarkGoldenrod1")
signup_frame.place(x="140",y="150")
    # signup frame widgets

#widget 1
fullname_label = Label(signup_frame,width="15",padx="5",pady="5",text="User Name",bg="DarkGoldenrod1",fg="light sea green",font=("Calibri",15,'bold')).grid(row=0,column=0,padx="5",pady="5")
fullname_entry = Entry(signup_frame,textvariable=name,selectbackground="light sea green",selectforeground="black",font=("Calibri",15,"italic")).grid(row=0,column=1,padx="15",pady="5")
#widget 2
email_label = Label(signup_frame,width="15",padx="5",pady="5",text="User Email",bg="DarkGoldenrod1",fg="light sea green",font=("Calibri",15,'bold')).grid(row=1,column=0,padx="5",pady="5")
email_entry = Entry(signup_frame,textvariable=email,selectbackground="light sea green",selectforeground="black",font=("Calibri",15,"italic")).grid(row=1,column=1,padx="15",pady="5")
#widget 3
password_label = Label(signup_frame,width="15",padx="5",pady="5",text="User Password",bg="DarkGoldenrod1",fg="light sea green",font=("Calibri",15,'bold')).grid(row=2,column=0,padx="5",pady="5")
password_entry = Entry(signup_frame,show="*",textvariable=password,selectbackground="light sea green",selectforeground="black",font=("Calibri",15,"italic")).grid(row=2,column=1,padx="15",pady="5")
#widget 4
gender.set("Radio")
gender_label = Label(signup_frame,width="15",padx="5",pady="5",text="User Gender",bg="DarkGoldenrod1",fg="light sea green",font=("Calibri",15,'bold')).grid(row=3,column=0,padx="5",pady="5")
gander_male = Radiobutton(signup_frame,text="Male",bg="DarkGoldenrod1",value="Male",width="6",variable=gender).place(x="130",y="137")
gander_female = Radiobutton(signup_frame,text="Female",bg="DarkGoldenrod1",width="8",value="Female",variable=gender).place(x="190",y="137")
gander_others = Radiobutton(signup_frame,text="Others",bg="DarkGoldenrod1",width="7",value="Others",variable=gender).place(x="270",y="137")
#widget 5
age_label = Label(signup_frame,width="15",padx="5",pady="5",text="User Age",bg="DarkGoldenrod1",fg="light sea green",font=("Calibri",15,'bold')).grid(row=4,column=0,padx="5",pady="5")
values = [int(i) for i in range(15,99)]
age.set("")
age_combo = ttk.Combobox(signup_frame,value=values,width="25",state="readonly",textvariable=age,font=("Arial",13,"italic")).grid(row=4,column=1)

#widget 6

signup_btn = Button(signup_frame,text="Sign Up",width="30",bg="light sea green",fg="DarkGoldenrod1",font=("Arial",15,"italic"),command=validation).grid(row=5,columnspan=2,pady="15",padx="10")

#extra addition
txt2=Label(text="click here to",font=("Clibri",12,"italic"),bg="light sea green").place(x="500",y="235")
txt2=Label(text="generate pswd",font=("Clibri",12,"italic"),bg="light sea green").place(x="500",y="250")
#7
sgnup_btn2 = Button(text="Password Generator",width="10",font=("Calibri",10,"bold"),fg="white",command=shift2pgen).place(x="600",y="240")

screen.mainloop()