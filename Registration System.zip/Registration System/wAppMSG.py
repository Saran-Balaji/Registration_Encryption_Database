from twilio.rest import Client 
 
account_sid = 'ACb8b549889d105f9517d0172179063adf' 
auth_token = '9a442fb9cc0eb98a67fcfe908e241067' 

client = Client(account_sid, auth_token) 

#ciphering_textfile
def vig(txt='', key=' ', typ='d'):
    if not txt:
        print ("Needs text.Error.")
        return
    if not key:
        print ("Needs key.Error.")
        return
    if typ not in ('d', 'e'):
        print ('Type must be "d" or "e".Error.')
        return

    k_len = len(key)
    k_ints = [ord(i) for i in key]
    txt_ints = [ord(i) for i in txt]
    ret_txt = ''
    for i in range(len(txt_ints)):
        adder = k_ints[i % k_len]
        if typ == 'd':
            adder *= -1

        v = (txt_ints[i] - 32 + adder) % 95

        ret_txt += chr(v + 32)

    return (ret_txt)
#end of ciphering code


with open('insertion.txt', 'r') as f:
    lines = f.read().splitlines()
    last_line = lines[-1]

entryList = last_line.split(',')
entryList[0]=vig(entryList[0], 'super secret key', 'd')
entryList[4]=vig(entryList[4], 'super secret key', 'd')
entrydata="A New Person just Registered! Their name is "+entryList[0]+" and they are "+entryList[4]+" years old."
print(entrydata)
message = client.messages.create( 
                              from_='whatsapp:+14155238886',  
                              body=entrydata,      
                              to='whatsapp:+918668139020' 
                          ) 
 
print(message.sid)