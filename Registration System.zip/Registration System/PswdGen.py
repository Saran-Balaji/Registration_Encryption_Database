import string
import random
from Tkinter import *
try:
    from Tkinter import tkMessageBox
except:
    # Python 2
    import tkMessageBox as messagebox
import re

def shift2su():
    root.destroy()
    import signup2

class GUI():

    def __init__(self,master):
        
        master.title('Password Generator')
        master.geometry('600x400')
        
        master.resizable(True, True)

        self.label=Label(text="Password Generator",fg='DarkGoldenrod2',font='elephant 35 bold')
        self.label.grid(row=0,column=0,columnspan=3)

        self.blank_label1=Label(text="")
        self.blank_label1.grid(row=1,column=0,columnspan=2)

        
        self.blank_label2=Label(text="")
        self.blank_label2.grid(row=2,column=0,columnspan=2)


        self.user=Label(text="Enter name of user:",fg='deep sky blue',font='times 25 bold italic')
        self.user.grid(row=5,column=0)

        self.textfield=Entry(font='times 20',bd=6,relief='groove')
        self.textfield.grid(row=5,column=1)
        #self.textfield.focus_set()

        
        self.blank_label3=Label(text="")
        self.blank_label3.grid(row=6,column=0)

        self.length=Label(text="Enter the length:",fg='lime green',font='times 25 bold italic')
        self.length.grid(row=7,column=0)

        self.length_textfield=Entry(font='times 20',bd=6,relief='groove')
        self.length_textfield.grid(row=7,column=1)

        
        self.blank_label4=Label(text="")
        self.blank_label4.grid(row=8,column=0)

        self.generated_password=Label(text="Generated Password:",fg='OrangeRed2',font='times 25 bold italic')
        self.generated_password.grid(row=9,column=0)

        self.generated_password_textfield=Entry(font='times 20',bd=6,relief='ridge',fg='darkgreen')
        self.generated_password_textfield.grid(row=9,column=1)
        #self.generated_password_textfield.configure(state='readonly')

        
        self.blank_label5=Label(text="")
        self.blank_label5.grid(row=10,column=0)

        
        self.blank_label6=Label(text="")
        self.blank_label6.grid(row=11,column=0)

        self.generate=Button(text="Generate Password",height=2,bd=0,relief='solid',padx=1,pady=1,font='forte 25 bold',fg='maroon',bg='limegreen',command=self.generate_pass)
        self.generate.grid(row=12,column=0)


        self.reset=Button(text="Reset All",height=2,bd=0,relief='solid',padx=0,pady=0,font='forte 25 bold',fg='darkblue',bg='red',command=self.reset_fields)
        self.reset.grid(row=12,column=2)

    def generate_pass(self):
         upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
         lower = "abcdefghijklmnopqrstuvwxyz"
         chars = "@#%&()\"?!"
         numbers = "1234567890"
         upper = list(upper)
         lower = list(lower)
         chars = list(chars)
         numbers = list(numbers)
         name=self.textfield.get()
         leng=self.length_textfield.get()

         if name=="":
             messagebox.showerror("Error Message.","Name field CAN'T be empty!")
             return
         
         if name.isalpha()==False:
             messagebox.showinfo("Error Warning.","Name MUST be a string! Don't include numbers or special characters.")
             self.textfield.delete(0,25)
             return
             
         if leng=='':
             self.blank_label2.configure(text="            Length field cannot be empty!",font='times 20 bold',fg='SpringGreen3')
             self.blank_label1.configure(text="")
             return
         else:
             self.blank_label2.configure(text="")

         if leng.isdigit()==False:    
            messagebox.showwarning("Warning","Length must be an integer. Don't enter alphabets or special characters.")
            self.length_textfield.delete(0,25)
            return

         length=int(leng)  
         
         if length<7:
              self.blank_label1.configure(text="Password must be atleast 7 characters long! (limit:40)",font='times 20 italic',fg='medium sea green')
              self.blank_label2.configure(text="")
              return
         else:
              self.blank_label1.configure(text="")
    

         
         self.generated_password_textfield.delete(0,length)
    
         u = random.randint(1, length-3)
         l = random.randint(1, length-2-u)
         c = random.randint(1, length-1-u-l)
         n = length-u-l-c
         password = random.sample(upper,u)+random.sample(lower,l)+random.sample(chars,c)+random.sample(numbers,n)
         random.shuffle(password)
         gen_passwd="".join(password)
         self.generated_password_textfield.insert(0,gen_passwd)
         #add extra link
         self.blank_label5.configure(text="Copy generated password.",font='times 20 bold',fg='blue')
         self.blank_label6.configure(text="Then go back to signup. -->",font='times 20 bold',fg='blue')
         sgnup_btn3 = Button(text="Sign Up",width="10",font=("Calibri",10,"bold"),fg="white",command=shift2su).place(x="240",y="295")
         

     
    def reset_fields(self):
        self.textfield.delete(0,25)
        self.length_textfield.delete(0,25)
        self.generated_password_textfield.delete(0,25)
        


#if __name__=='__main__':
root=Tk()
pass_gen=GUI(root)
root.mainloop()